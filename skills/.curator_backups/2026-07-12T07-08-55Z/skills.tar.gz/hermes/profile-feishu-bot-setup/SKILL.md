---
name: profile-feishu-bot-setup
description: "完整流程：创建Hermes Profile + 配置专用飞书机器人 + s6多gateway管理"
version: 1.0.0
author: Hermes Agent
metadata:
  hermes:
    tags: [profile, feishu, gateway, s6, docker, multiplex]
---

# Profile + 飞书机器人配置工作流

适用于 Docker 部署的 Hermes（s6 进程管理），为每个 Profile 配置独立的飞书机器人。

## 前置条件
- Docker 部署的 Hermes，容器名通常为 `hermes-main`
- 已有飞书开放平台账号 https://open.feishu.cn/
- HERMES_HOME 映射到宿主机目录（本流程假设宿主机 `~/.hermes-main` → 容器 `/opt/data`）

## 完整步骤

### Step 1: 飞书开放平台创建新 Bot

1. 登录 https://open.feishu.cn/ → **创建应用** → **企业自建应用**
2. 应用名称自定义（如"投资助手"）
3. **凭证与基础信息** → 记下 `App ID`、`App Secret`
4. **应用功能 → 机器人** → 开启 ✅
5. **权限管理** → 添加：
   - `im:message`（接收消息）
   - `im:message:send_as_bot`（发送消息）
6. **事件与回调** → 连接方式选 **长连接(WebSocket)**
   - **添加事件** → `im.message.receive_v1`（必须！）
7. **版本管理与发布** → 创建版本 → 申请发布 → 审批通过

### Step 2: 创建 Profile（宿主机执行）

```bash
docker exec hermes-main bash -c 'export PATH=$PATH:/opt/data/.local/bin && hermes profile create 投资-profile名 --clone'
```

> `--clone` 会自动复制 default 的 config.yaml、.env、SOUL.md、skills

### Step 3: 编辑 .env（宿主机直接编辑）

```bash
vi ~/.hermes-main/profiles/投资-profile名/.env
```

**只需要改飞书相关行**，其他 API Key（DeepSeek、OpenRouter 等）保持不动：

```
FEISHU_APP_ID=cli_...新bot的ID
FEISHU_APP_SECRET=***
FEISHU_DOMAIN=feishu
FEISHU_CONNECTION_MODE=websocket
FEISHU_ALLOW_ALL_USERS=false
# ⚠️ ALLOWED_USERS 留空！第一次发消息后查日志获取正确 OpenID
# FEISHU_ALLOWED_USERS=
FEISHU_GROUP_POLICY=open
FEISHU_HOME_CHANNEL=
FEISHU_HOME_CHANNEL_THREAD_ID=
```

> **关键坑**：不同飞书 Bot 给同一用户的 OpenID 可能不同。先留空 ALLOWED_USERS，发消息后查日志获取。

### Step 4: 编写 SOUL.md

编辑 `~/.hermes-main/profiles/投资-profile名/SOUL.md`，定义该 Profile 的角色和语言偏好。

**语言指令必须放最前面**（深度求索等模型可能忽略后半部分）：

```
【语言指令——必须遵守】
你必须始终使用简体中文回复用户。
即使用户发英文、表情、符号、代码，也必须用中文回答。

# 角色名称
[以下写具体的角色定义]
```

### Step 5: 配置显示语言和人格

```bash
docker exec hermes-main bash -c 'export PATH=$PATH:/opt/data/.local/bin && \
  hermes -p 投资-profile名 config set display.language zh && \
  hermes -p 投资-profile名 config set display.personality 投资-助手'
```

> personality 需要在 config.yaml 的 `agent.personalities` 段中预先定义。

### Step 6: 禁用无关平台

编辑 `~/.hermes-main/profiles/投资-profile名/config.yaml`，只保留 feishu：

```yaml
platforms:
  feishu:
    enabled: true
```

删除 dingtalk、telegram、weixin 等无关平台。

### Step 7: 替换 Memory

编辑 `~/.hermes-main/profiles/投资-profile名/memories/MEMORY.md` 和 `USER.md`，写入该 Profile 专用的记忆。

MEMORY.md 格式：
```
关键事实1
§
关键事实2
§
关键事实3
```

### Step 8: 启动 Gateway

```bash
docker exec hermes-main bash -c 'export PATH=$PATH:/opt/data/.local/bin && \
  hermes -p 投资-profile名 gateway start'
```

> ⚠️ **不要设置 `gateway.multiplex_profiles: true`**！Docker s6 架构使用每个 Profile 独立的 gateway 进程，multiplex 会冲突。

### Step 9: 获取用户 OpenID

给新飞书 Bot 发一条消息 → 查看日志获取 OpenID：

```bash
docker exec hermes-main cat /opt/data/profiles/投资-profile名/logs/gateway.log | grep "Unauthorized"
```

输出示例：
```
Unauthorized user: ou_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx on feishu
```

将 OpenID 写入 .env：

```bash
vi ~/.hermes-main/profiles/投资-profile名/.env
# FEISHU_ALLOWED_USERS=ou_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Step 10: 重启 Gateway

```bash
docker exec hermes-main bash -c 'export PATH=$PATH:/opt/data/.local/bin && \
  hermes -p 投资-profile名 gateway restart'
```

## 验证清单

- [ ] `ps aux | grep "gateway run"` → 看到新 profile 的 python 进程
- [ ] 飞书 Bot 回复中文
- [ ] 只有被允许的用户能使用
- [ ] s6 自动管理（容器重启后自动恢复）

## 常见坑

| 坑 | 解决 |
|:---|:-----|
| 飞书没回复 | 检查 `FEISHU_CONNECTION_MODE=websocket` 和 `im.message.receive_v1` 事件 |
| Unauthorized user | OpenID 不同，查日志获取正确值 |
| Telegram/微信 token 冲突 | 禁用无关平台（Step 6） |
| 回复英文 | SOUL.md 语言指令放最前面 + display.language=zh |
| multiplex 冲突 | 不要设置 multiplex_profiles，s6 原生支持多 gateway |
| `--clone` 后 memory 是 default 的内容 | 必须手动替换为 Profile 专用记忆 |
