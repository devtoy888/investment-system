---
name: hermes-session-management
description: "Inspect, manage, and maintain Hermes Agent sessions — listing, selective batch-deletion, auto-prune configuration, and database health."
version: 1.1.0
author: Hermes Agent
tags: [hermes, sessions, maintenance, cleanup, lifecycle]
---

# Hermes Session Management

Hermes stores all conversations in an SQLite database at `~/.hermes/state.db` (or under `$HERMES_HOME`). Over time, cron test runs, short greetings, and CLI tests accumulate and bloat the database. This skill covers lifecycle management.

## CLI Reference

All session commands are available via `hermes sessions`:

| Command | Purpose |
|---------|---------|
| `hermes sessions list` | Show recent sessions (title, preview, age, ID) |
| `hermes sessions stats` | Session store statistics (count, messages, DB size) |
| `hermes sessions delete <ID>` | Delete a single session |
| `hermes sessions prune --older-than N` | Bulk-delete sessions older than N days |
| `hermes sessions rename <ID> <TITLE>` | Rename a session |
| `hermes sessions export <PATH>` | Export to JSONL |

## Searching & Switching Sessions

### Cross-session full-text search

The `session_search` tool searches ALL sessions in the SQLite database via FTS5, not just the 20 most recent:

| Shape | When to use | Example |
|-------|-------------|---------|
| **Discovery** (by query) | Find sessions about a topic | `session_search("Agent Reach 日报")` |
| **Scroll** (within session) | Read more context around a match | `session_search(session_id="...", around_message_id=N, window=10)` |
| **Read** (full session) | Dump entire session by ID | `session_search(session_id="...")` |
| **Browse** (no args) | See recent sessions chronologically | `session_search()` |

**FTS5 query syntax:**
- Multi-word = AND by default — `Agent Reach 日报` matches sessions containing ALL three terms
- `OR` for broader recall — `Agent OR Reach`
- `"exact phrase"` — `"Hermes Gateway"` matches only that exact phrase
- Prefix wildcard — `deploy*` matches deploy, deployment, deploying
- Boolean — `python NOT java`

**Best practice for recall:** When the user asks "find the session where we did X", use session_search first — don't fall back to `hermes sessions list` (only shows 20 recent sessions) or SQLite queries (no full-text).

### Session switching (gateway-level)

When the agent or user is in the wrong session, switch using:

```
@session:<profile>/<session_id>
```

For the default profile:
```
@session:default/20260624_075822_a51db8c5
```

**Behavior:** The gateway loads the target session's context — both agent and user see the session's history. The user sends this as a message in their chat. Old sessions that are months old can still be navigated to this way — they are never lost unless explicitly deleted.

**WARNING about deletion:** You CAN switch into a session and then delete it from within — but that terminates the current conversation. Always confirm with the user before deleting the session they're actively using.

## Pitfalls

### 1. `hermes sessions delete` requires interactive confirmation

The command prompts `Delete session 'ID' and all its messages? [y/N]`. Without confirmation input, the deletion is silently **Cancelled** — the exit code is still 0, so it looks like it succeeded.

**Fix:** Pipe `y` to the command:
```bash
echo "y" | hermes sessions delete <SESSION_ID>
```

**Batch pattern:**
```bash
for id in session1 session2 session3; do
  echo "y" | hermes sessions delete "$id"
done
```

### 2. `hermes sessions list` truncates at 20 rows

The CLI only shows the 20 most recent sessions even when the database has many more. **Do NOT use SQLite queries for recall** — the `session_search` tool is the correct approach:

```python
# ❌ BAD — use hermes sessions list or SQLite when user asked about finding sessions
# ✅ GOOD — use session_search(query) in the agent's own toolset
```

The tool supports FTS5 full-text search across ALL sessions, returning the top matches with bookend context (first/last messages + ±5 around the match) — no need for raw SQL.

### 3. User teaching preference

When the user asks about session management ("如何列举所有会话", "如何删除会话"), **teach them the CLI commands** rather than silently executing everything. Show the exact command and let them choose to run it. This builds their understanding of the system. When they then say "do it", proceed with execution.

## Auto-Prune Configuration

Hermes automatically prunes old sessions. Configure in `config.yaml`:

```yaml
sessions:
  auto_prune: true              # Enable auto-cleanup
  retention_days: 30            # Keep sessions for N days (adjust for your needs)
  min_interval_hours: 24        # Check frequency
  vacuum_after_prune: true      # Reclaim disk space after pruning
```

**Evaluation guidance:**
- **30 days**: Good default if you don't need long-term history
- **90–180 days**: Recommended for users with substantive recurring conversations (model tuning, daily briefings, etc.)
- **0 / false**: Disable auto-prune for full manual control (risk: DB grows unbounded)
- Consider the age of your earliest valuable session when setting `retention_days`

## Workflow: Selective Bulk Cleanup

1. **Assess** — `hermes sessions stats` for total count + DB size
2. **Inventory** — Use Python/SQLite to list all sessions with title, source, message_count
3. **Categorize** what's safe to delete:
   - Cron test/debug runs (titles like "行业技术日报 · Jun DD HH:MM" with 1–50 messages)
   - Short platform greetings (3–5 messages, boilerplate titles)
   - Empty CLI sessions (1–2 messages, no title)
   - Historical debug sessions for already-resolved issues
4. **Delete** — Batch with `echo "y" | hermes sessions delete <ID>` in a shell loop
5. **Verify** — Re-check stats to confirm

## Retaining Valuable Sessions

Sessions worth keeping typically have:
- 100+ messages (substantive debugging/configuration)
- Meaningful titles (model setup, platform integration, cron workflow fixes)
- Cross-platform interactions (QQ + Feishu + WeChat coordination)

When in doubt, preserve and prune later — deletion is irreversible.
