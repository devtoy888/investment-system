# Cron Configuration (deployed 2026-06-26)

## 今日参考 (盘前简报)

| Field | Value |
|-------|-------|
| Job ID | `d7b0ad464c01` |
| Schedule | `0 0 * * 1-5` (Mon-Fri 00:00 UTC = 08:00 BJ) |
| Script | `collect_morning_data.py` |
| Deliver | `qqbot:82BC393B5BF9B2DC01006D6DFA66CB9B` |
| Toolsets | terminal, file, web |

**Final verified prompt (after 5+ format iterations on 2026-06-26):**

```
数据已由 collect_morning_data.py 预采集到 /tmp/fund_data/。

读取数据：
cat /tmp/fund_data/_overnight_summary.txt
cat /tmp/fund_data/_market_summary.txt
cat /tmp/fund_data/_group_summary.txt
cat /tmp/fund_data/_fund_summary.txt
cat /tmp/fund_data/_kol_summary.txt

你是一名财经晨报编辑。用采集到的数据生成一份《今日参考》。

颜色规则（A股惯例）：上涨用 🔴 标识，下跌用 🟢 标识。每个涨跌幅数字前面必须加对应颜色的圆点。

格式：
━━━ 今日参考 · 日期(周X) ━━━

🌙 隔夜外盘
| 品种 | 收盘 | 涨跌 |
（道琼斯/标普500/纳斯达克/黄金期货/美元指数）

📊 A股收盘 · 月X日(周X)
| 指数 | 收盘 | 涨跌 |
（上证指数/创业板指/科创50/沪深300/黄金ETF市场价）
注：黄金ETF市场价（sz159934）跟踪上海金交所Au99.99，与你的黄金基金净值不同，仅作金价参考

💰 持仓分组
简洁表格展示各组表现

📰 博主信号

【唐史主任司马迁】[已验证6/6]
• 核心信号方向

【小浣熊1230】
• 风险警示或宏观判断

📌 今日关注
• 操作建议（买/卖/持有/不动）
• 如有未持仓板块的信号提示，加「值得关注」

要求：
- 所有涨跌幅必须加🔴（涨）🟢（跌）标识
- A股收盘标注具体日期
- 不包含IT精英带你养基
- 不使用分类标签「发生了什么」「影响评估」等
- 最后不要装饰性结尾

deliver="origin"
```

### Key Formatting Rules Discovered in Testing

1. **不要写「不要表格」** — that destroys the markdown tables the user wants.
2. **不要用模板语法 `{{datetime.now()}}`** — cron prompts are plain text, Jinja is not supported.
3. **不要IT精英** — removed from all 08:00 and 15:30 push prompts (11:35 script already excludes him).
4. **每改一次就触发一次 `cronjob action=run`** 验证，否则用户不知效果。

## 盘中速递

| Field | Value |
|-------|-------|
| Job ID | `d29e6063c469` |
| Schedule | `35 3 * * 1-5` (Mon-Fri 03:35 UTC = 11:35 BJ) |
| Script | `collect_noon_data.py` |
| Deliver | `qqbot:82BC393B5BF9B2DC01006D6DFA66CB9B` |
| Toolsets | terminal, file |

**Verified prompt:**

```
数据已由 collect_noon_data.py 预采集到 /tmp/fund_data/。
cat /tmp/fund_data/_noon_market.txt
cat /tmp/fund_data/_noon_group.txt
cat /tmp/fund_data/_noon_fund.txt
cat /tmp/fund_data/_noon_kol.txt
格式化成盘中速递，注意：不要包含IT精英带你养基的内容。简洁为主。
deliver="origin"
```

## 收盘复盘

| Field | Value |
|-------|-------|
| Job ID | `7a165a5748ce` |
| Schedule | `0 8 * * 1-5` (Mon-Fri 08:00 UTC = 16:00 BJ) |
| Script | `closing_review.py` |
| Deliver | `qqbot:82BC393B5BF9B2DC01006D6DFA66CB9B` |
| Toolsets | terminal, file |
