# Weekend Overseas Market Push (周六外盘速报)

> Implemented 2026-06-26

## Purpose

Friday US market trades 21:30–04:00 CST (Fri→Sat). Previously, this data was not pushed until Monday 08:00 — wasting 2 days of advance planning time for the user. A light Saturday push lets the user mentally prepare for Monday over the weekend.

## Cron Configuration

| Field | Value |
|-------|-------|
| Name | 周末外盘速报 |
| Schedule | `0 1 * * 6` (UTC) = 09:00 CST Saturday |
| Type | `no_agent=true` |
| Script | `collect_weekend_data.py` |
| Delivery | `qqbot:<chat_id>` |

## Script Design (`collect_weekend_data.py`)

Located at `/opt/data/scripts/collect_weekend_data.py`

Reuses existing `fund_tools` functions:
- `_yahoo_quote()` — fetches overnight/overseas quotes
- `get_user_weibos()` — checks for weekend KOL posts

### Output Format (stdout = push content)

```
━━━ 周末外盘速报 · M月D日(六) ━━━

🌙 上周五美股收盘
  品种 | 收盘 | 涨跌
  道琼斯 | X | (+Y%)
  标普500 | X | (+Y%)
  纳斯达克 | X | (-Y%)
  黄金期货 | $X | (+Y%)
  美元指数 | X | (-Y%)

📌 周一参考
  ● 以上为周五收盘，周一A50开盘将反映外盘变化
  ● 周末重大事件将于周一「今日参考」更新

📰 博主周末动态
  [唐史主任] 精选最新有效博文片段
  [小浣熊1230] 精选最新有效博文片段
```

### Date Handling

- Script detects if running on Saturday → calculates Friday date
- Title shows Saturday's date, body says "上周五美股"
- Filters out KOL 置顶/公告 posts; IT精英 excluded

### Edge Cases

| Case | Behavior |
|------|----------|
| Friday was a Chinese holiday | Yahoo returns last close before holiday. Still pushes, mentions "上周X收盘" |
| KOL didn't post over weekend | Shows "（周末暂无博主新信号）" |
| Yahoo API fails | Shows error per symbol, still delivers partial data |
| Monday holiday (run on Saturday after Fri trading) | Pushes normally, data is valid |
