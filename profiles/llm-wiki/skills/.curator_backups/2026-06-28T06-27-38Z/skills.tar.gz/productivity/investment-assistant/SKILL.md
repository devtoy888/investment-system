---
name: investment-assistant
description: 个人投资决策辅助系统 — 市场数据采集(腾讯/天天基金) + 持仓跟踪 + KOL信号(微博) + AI分析/解读 + 每日参考推送 + 收盘验证 + 数据归档(JSONL+R2) + SPA查阅页面。整合 cron-content-pipeline + china-market-data + weibo-monitor 三大skill。
tags: [fund, stock, portfolio, daily-briefing, weibo, A-share, data-collection]
---

# Investment Assistant — 个人投资决策辅助系统

Build a complete personal investment decision support system that collects market data, tracks portfolio funds, monitors KOL signals, generates daily briefings with AI analysis, verifies predictions at close, and archives everything for review.

## Architecture

```
                        ┌─ Retry Queue ──┐
                        │ 9:00→9:10      │
                        └──────┬─────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│               Data Collection (pre-script)                  │
│  Tencent quotes + Fund values + Weibo KOL posts + AI black │
│  talk interpretation → summary files to /tmp/fund_data/    │
└──────────────────────────────┬──────────────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │   Agent formats      │
                    │   morning brief      │
                    │   (reads summaries)  │
                    └──────────┬──────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
         ▼                     ▼                     ▼
    ┌────────┐          ┌──────────┐          ┌──────────┐
    │ Push to│          │ JSONL to │          │ Images   │
    │ QQ/WX  │          │ R2       │          │ to R2    │
    └────────┘          └─────┬────┘          └──────────┘
                              │
                              ▼
                      ┌──────────────┐
                      │ SPA Dashboard│
                      │ (R2 static)  │
                      └──────────────┘
```

## When to Activate

- User wants daily market/fund briefing automated
- User holds a portfolio of funds (ETF connections, active funds)
- User follows KOLs on Weibo for investment signals
- User wants predictions verified (closing review vs morning forecast)
- User needs a dashboard/history for manual review
- Keywords: 基金, ETF, 持仓, 今日参考, 盘前简报, 收盘复盘, 投资辅助, 个人理财, 定投, 波段

## Strategy Framework (3-Push Design)

Designed around a proven financial framework: the investment bank morning meeting 3-Box model (Goldman Sachs / Morgan Stanley standard structure).

### Core Decision Chain

The three pushes form a single decision loop:

```
08:00 → "What's my plan today?"      (set thesis)
11:35 → "Is the thesis holding?"     (verify in real-time)
15:30 → "Was the thesis right?"      (close loop, learn)
```

### Theoretical Foundations

| Framework | Source | Application |
|-----------|--------|-------------|
| 3-Box Morning Meeting | GS/MS standard | Push content structure (overnight → impact → action) |
| Factor Momentum + Sector Rotation | Jegadeesh & Titman (1993) | What data to track (sector flows, factor exposure) |
| Behavioral Finance | Kahneman (2011) | Why closing review exists (confirmation bias countermeasure) |
| Portfolio Rebalancing | Standard | When to suggest position adjustment (% deviation trigger) |
| Data Saturation Sampling | Guest et al. (2006) | KOL profile methodology (when is enough data enough) |

### The Push Schedule (US/A-Share Time-Gap Aware)

### Time Zone Foundation (EDT summer, China = UTC+8)

```
US market:  09:30 ET = 21:30 CST  →  16:00 ET = 04:00 CST (+1 day)
A50 night:  17:00-05:15 CST (+1 day)
```

### Key Timing Issues

The US market closes at **04:00 CST** — 4 hours before the 08:00 push. This works **Tue–Fri** but creates problems around the weekend:

| Day | Issue | Severity |
|-----|-------|:--------:|
| **Mon 08:00** | "隔夜外盘" is from Friday (stale by ~76h). Must not use the word 隔夜. | 🔴 Critical |
| **Fri 16:00** | A-share closed but US opens at 21:30 CST tonight — missing forward guidance. | 🟡 Medium |
| **Sat ~04:00** | Friday US close data arrives but no push collects it. Wasted until Monday. | 🟡 Medium |

### Full Push Schedule

| Beijing | Push Name | Days | Purpose | Content Focus |
|---------|-----------|:----:|---------|---------------|
| 08:00 (00:00 UTC) | 盘前简报 | Mon-Fri | Set daily thesis | **Tue-Fri:** Overnight US/gold/A50 (~4h fresh). **Mon:** Weekend events + Friday US close (marked as stale, NOT called "隔夜"). Supplement with web_search for weekend news. |
| 11:35 (03:35 UTC) | 盘中速递 | Mon-Fri | Verify + adjust | Morning session recap + portfolio estimate + new KOL signals + afternoon outlook |
| 15:30/16:00 (07:30/08:00 UTC) | 收盘复盘 | Mon-Fri | Close loop | Closing data + prediction accuracy. **Fri edition:** append 🌙 section "今晚美股关注" — preview US market tonight. |
| **09:00 (01:00 UTC)** | **周末外盘速报** | **Sat only** | Weekend reference | Light no_agent script push: Friday US close (DJI/SPX/IXIC/gold/USD) + A50 Friday close. Just data, no AI analysis. Lets user mentally prepare for Monday over the weekend. |

### Monday-Specific Rules

When the cron runs on Monday 08:00 (which is the first push after Friday 16:00):

1. **Do NOT write "隔夜外盘"** — the US market last traded ~76 hours ago. Write "上周五外盘关盘".
2. **Do NOT pretend the data is fresh** — add a note like "周末无交易，以上为上周五收盘数据".
3. **Supplement with web_search for weekend events** — policy changes, geopolitics, commodity moves. Include a "📰 周末大事" section before the regular content.
4. **A50 futures Friday night close** is included but also stale. Mention it without claiming it's real-time.
5. **KOL posts from the weekend** (Mon 08:00) are valuable — they may have posted Sat/Sun about Monday's outlook. Prioritize these over stale market data.

### Saturday AM Push Design

**Purpose:** Just the numbers — no AI commentary, no analysis. A quick-reference card for the weekend.

**Cron config:** `0 1 * * 6` (UTC) = 09:00 CST Saturday
**Type:** `no_agent=true`, script reuses `get_overnight_quotes()` from fund_tools.py

```
━━━ 周末外盘速报 · 6月27日(六) ━━━

🌙 周五美股收盘
| 品种 | 收盘 | 涨跌 |
|------|------|------|
| 道琼斯 | 51,920 | +0.84% |
| 标普500 | 7,357 | +0.52% |
| 纳斯达克 | 21,845 | -0.12% |
| 黄金期货 | $2,418 | -0.30% |
| 美元指数 | 101.2 | +0.15% |

（以上为周五收盘，周一开盘以实际为准）
```

### Friday Evening US Market Preview (added to 16:00 收盘复盘)

Append a section when the cron runs on Friday:

```
🌙 今晚美股关注
● 21:30 美股开盘（关注科技股/黄金/美元走势）
● 若有大幅波动，周末将推送外盘速报
```

## Integration with Existing Skills

| Component | Backend Skill | Purpose |
|-----------|--------------|---------|
| Data collection | `china-market-data` | Tencent quotes + fund values |
| Weibo signals | `weibo-monitor` | KOL posts + auth + black talk |
| Cron scheduling | `cron-content-pipeline` | Pre-script + agent pattern |
| Data storage | `cloudflare-r2` | JSONL archive + HTML site |

## Data Collection Library (fund_tools.py)

Create a single Python module (`scripts/fund_tools.py`) that provides all data collection functions and R2 storage. Structure:

```
fund_tools.py
├── get_tencent_quote(code)        → dict (name/price/change_pct/pe/pb)
├── get_all_quotes()               → dict of all tracked indices/ETFs
├── get_fund_value(fund_code)      → dict (nav/estimated_nav/estimated_change)
├── get_all_funds()                → dict of all held fund codes
├── get_user_weibos(uid, count=5)  → list of recent weibo posts
├── interpret_weibo(text, author)  → black talk keyword interpretation
├── group_funds(fund_data)         → group by theme (科技/黄金/其他)
├── store_jsonl(record, filename)  → append to local + sync to R2
├── upload_to_r2(file, key)        → upload to Cloudflare R2
├── is_trading_day()               → check weekday (extend for holidays)
└── FUND_CODES / KOLS / QUOTES    → configuration constants
```

### Fund portfolio classification (current as of 2026-06-26)

Group funds by theme, not individually. Each group should have a unified action signal.

**CRITICAL: Fund codes were initially extracted from screenshots and had ~50% error rate.** Always verify every fund code via the 天天基金 API before trusting it.

Current verified portfolio (21 funds, all confirmed via API):

| Group | Codes | Total(¥) | Signal |
|-------|-------|:--------:|--------|
| 黄金(2) | 002963, 009478 | ~1,257 | Gold price direction |
| 科技/AI(10) | 011613, 024418, 026449, 026421, 014871, 020233, 017103, 011712, 026200, 013403 | ~4,374 | Tech/AI sector trend |
| 资源/周期(2) | 163302, 025857 | ~638 | Resource cycle exposure |
| 新能源(2) | 012329, 011103 | ~761 | New energy + solar |
| 医药(1) | 024329 | ~10 | (minimal) |
| 通航(1) | 024913 | ~17 | (minimal) |

Tencent quote codes for key indices:
- 上证指数: sh000001
- 创业板指: sz399006
- 科创50: sh000688
- 沪深300: sh000300
- 黄金ETF: sz159934

## Reference Files

- `scripts/collect_morning_data.py` — Pre-collection script (runs before agent as cron's `script` parameter). Available at `/opt/data/scripts/` on this host.
- `scripts/fund_tools.py` — Reusable data collection library. Available at `/opt/data/scripts/` on this host.
- `scripts/closing_review.py` — Closing review data collection. Available at `/opt/data/scripts/` on this host.
- `scripts/kol_expand_phase2.py` — KOL data collection with pagination. Available at `/opt/data/scripts/` on this host.
- `references/kol-analysis.md` — KOL profile analysis findings (227+80+80 posts analyzed).
- `references/kol-following-analysis.md` — 唐史主任's following list analysis (negative finding).
- Strategy document on R2: `fund-system/strategy/STRATEGY_v1.md`
- Strategy v2 on R2: `fund-system/strategy/STRATEGY_v2.md`
- Accuracy report on R2: `fund-system/strategy/KOL_ACCURACY_REPORT_v1.md`
- Black talk analysis on R2: `fund-system/data/kol_blacktalk_analysis.json`
- KOL profile data on R2: `fund-system/data/kol_profiles/final_profiles.json`
- Friday evening US market preview (added to closing review 2026-06-26): `references/timing-analysis.md`
- Holiday calendar (CHINESE_HOLIDAYS_2026 + auto-scrape 2026-06-26): `references/holiday-handling.md`
- Saturday weekend overseas push (no_agent script 2026-06-26): `references/weekend-push.md`
- Cron job configuration (deployed 2026-06-26): `references/cron-config.md`

## Overseas Market Data (Yahoo Finance)

Added to fund_tools.py (2026-06-26): `get_overnight_quotes()` function.

**Verifiable symbols** (confirmed working via Yahoo Finance API):

| Market | Symbol | URL Encoding |
|--------|--------|-------------|
| Dow Jones | `^DJI` | `%5EDJI` |
| S&P 500 | `^GSPC` | `%5EGSPC` |
| Nasdaq | `^IXIC` | `%5EIXIC` |
| Gold Futures | `GC=F` | `GC%3DF` |
| US Dollar Index | `DX-Y.NYB` | `DX-Y.NYB` |

**Failed attempts** (do not retry): A50 futures via Yahoo Finance (symbol `XIN9.F`, `FTXIN9`, `CN` all returned non-futures data).

```python
# Usage:
from scripts.fund_tools import get_overnight_quotes
quotes = get_overnight_quotes()
# Returns: {'道琼斯': {'price': 51920.62, 'change_pct': 0.14}, ...}
# Note: Yahoo's regularMarketPrice is LATEST (not necessarily yesterday close).
# For 08:00 Beijing = ~20:00 ET = US market closed, so latest = yesterday close. ✓
```

## Pre-Script + Agent Cron Pattern

Use the cron-content-pipeline Pre-Script Data Collection pattern:

### Pre-script (collect_morning_data.py)

```python
# What it does:
# 1. Check if today is a trading day (skip if not)
# 2. Collect market data, fund values, weibo KOL posts
# 3. AI-interpret KOL posts for black talk (画像驱动的过滤)
# 4. Group funds by theme
# 5. Check for new sector opportunities
# 6. Write summary files to /tmp/fund_data/_*.txt
# 7. Save raw data JSON to JSONL + R2 for archival
```

### Skip File Protocol (for non-trading days)

Each pre-collection script writes a skip file when `is_trading_day()` returns False. The cron prompt MUST check for this file in the very first step — otherwise the AI agent will push stale/empty data on holidays.

| Script | Skip File |
|--------|-----------|
| `collect_morning_data.py` | `/tmp/fund_data/_skip.txt` |
| `collect_noon_data.py` | `/tmp/fund_data/_noon_skip.txt` |
| `closing_review.py` | `/tmp/fund_data/_closing_skip.txt` |

Prompt template for Step 1:
```
## 第一步：检查是否交易日
如果 `/tmp/fund_data/_skip.txt` 存在，说明今天不是A股交易日。输出"⏭️ 今日休市，无推送"并结束（不要发送任何其他内容）。
```

**Why this matters:** Before this pattern was added (2026-06-26), `closing_review.py` exited on holidays but wrote NO skip file — the AI agent would find no data files, then hallucinate a report based on empty input. Every pre-script + agent cron pair must implement this protocol.

Use the 3-Box model for the 08:00 push:

```
数据已由 collect_morning_data.py 预采集到 /tmp/fund_data/。

步骤1：读取数据
  cat /tmp/fund_data/_market_summary.txt
  cat /tmp/fund_data/_group_summary.txt
  cat /tmp/fund_data/_fund_summary.txt
  cat /tmp/fund_data/_kol_summary.txt （画像驱动过滤后的信号）

步骤2：格式化成盘前简报
用上述数据按此模板写中文盘前简报：
━━ 今日参考 · 日期 ━
🌙 隔夜外盘（Box 1）
📊 昨收A股（Box 1）
💰 持仓分组（Box 2）
📰 博主信号（Box 2 - 画像驱动）
🚀 新赛道关注（Box 2 - 可选）
📌 今日建议（Box 3）

步骤3：deliver="origin" 回到对话来源
```

## 唐史主任 6/6 准确性验证证据链

Each claim was independently verified via web search against external news sources.

| # | 他的原话 | 日期 | 验证方法 | 结果 |
|:-:|---------|:----:|---------|:----:|
| 1 | 「美光的业绩出来了，全超，所有指标都超」 | 6/25 | 搜「美光2026Q3 营收」确认414.6亿美元(+346%), 毛利率84.9% | ✅ |
| 2 | 「两市昨天成交3.76万亿」 | 6/23 | 搜「A股 6月22日 成交额 3.76万亿」确认历史第二 | ✅ 精确到数字 |
| 3 | 「科创综指创业板指等都新高」 | 6/23 | 搜「科创50 6月24日 历史新高」确认1989.43点(+3.82%) | ✅ |
| 4 | 「棒子那是去掉一些杠杆……国内的存储今天还是涨的」 + 「昨天白天是韩国熔断」 | 6/23-6/24 | 搜「韩国股市 6月23日 熔断」确认KOSPI跌8.11% | ✅ |
| 5 | 「指数已经基本完成本次回踩」 | 6/16 | 搜「6月16日 上证 回踩 4090 MACD金叉」确认站上四线 | ✅ |
| 6 | 「科技方向在反弹中占优」 | 4/9 | 跟踪Q2科创50从4月到6月连创新高 | ✅ 趋势正确 |

**验证原则（适用于任何KOL评估）：**
1. 事实陈述（成交量、业绩等）→搜索新闻确认数字
2. 趋势判断（触底、回踩等）→搜索后续技术指标确认
3. 时限判断（某事件在何时发生）→搜索事件时间线确认
4. 不验证无标准答案的判断（"看好科技"、"风格轮动"等模糊表述不计入统计）
5. 多来源交叉验证（至少两个独立新闻源）

### 三位博主定位

| 博主 | 信号密度 | 风格 | 推送角色 | 采集策略 |
|------|:-------:|------|---------|---------|
| 唐史主任司马迁 | 26.7% | 操作信号+情绪引导 | 主力信号源 | 近5条 - 信号词加权提取买入信号 |
| 小浣熊1230 | 26.3% | 宏观分析+风险警示 | 风险补充信号 | 近5条 - 提取风险警示信号 |
| **IT精英带你养基** | **7.5%** | **日常定投记录** | **情绪参考** | **近3条 - 仅取「今天亏了X」情绪数据。不用于配比参考** |\n### Script References (2026-06-26 implementation)

| Script | Location | Purpose | Created/Updated |
|--------|----------|---------|:---------------:|
| `fund_tools.py` | `/opt/data/scripts/` | Core data lib (domestic + Yahoo Finance overseas) | Updated |
| `collect_morning_data.py` | `/opt/data/scripts/` | 08:00 pre-script (incremental writes) | Updated |
| `collect_noon_data.py` | `/opt/data/scripts/` | 11:35 pre-script (midday) | **New** |
| `collect_weekend_data.py` | `/opt/data/scripts/` | Sat 09:00 no_agent weekend overseas push | **New** |
| `closing_review.py` | `/opt/data/scripts/` | 15:30 closing review (now writes _closing_skip.txt on holidays) | Updated |
| `kol_analyze_phase0.py` | `/opt/data/scripts/` | KOL initial profiling (20 posts) | Historic |
| `kol_analyze_phase1.py` | `/opt/data/scripts/` | KOL expansion profiling (50 posts) | Historic |
| `kol_analyze_final.py` | `/opt/data/scripts/` | KOL saturation verification | Historic |
| `kol_evaluate_candidates.py` | `/opt/data/scripts/` | Candidate KOL quality filter | Historic |
| `kol_deep_mofei.py` | `/opt/data/scripts/` | 莫非 deep evaluation (300 posts) | Historic |
| `kol_sector_gap.py` | `/opt/data/scripts/` | Holdings vs Tang industry coverage | Historic |

### R2 Strategy Documents

| Document | R2 Path | Version |
|----------|---------|:-------:|
| System Design v1 | `fund-system/strategy/SYSTEM_DESIGN_v1.md` | Complete architecture + task backlog, 2026-06-26 |
| Timing Analysis v1 | `fund-system/strategy/TIMING_ANALYSIS_v1.md` | Weekend gap analysis, 2026-06-26 |
| Strategy v1 | `fund-system/strategy/STRATEGY_v1.md` | Initial |
| Strategy v2 | `fund-system/strategy/STRATEGY_v2.md` | After implementation |
| Accuracy Report | `fund-system/strategy/KOL_ACCURACY_REPORT_v1.md` | KOL verification |
| Black Talk JSON | `fund-system/data/kol_blacktalk_analysis.json` | Full term analysis |
| Final Profiles | `fund-system/data/kol_profiles/final_profiles.json` | All 3 KOLs |
| 莫非 Deep | `fund-system/data/kol_profiles/mofei_deep_analysis.json` | 300-post eval |
| Sector Gap | `fund-system/data/kol_profiles/sector_gap_analysis.json` | Holdings comparison |

> 用户问「我总感觉他是为了唱空而唱空，你验证下」→ 经300条数据深挖，他不是。

**基础数据：** 300条博文，38天跨度，7.9条/天，均长95字

**多空比变化（证明他随行情调整，不是单一空头）：**

| 时段 | 空头% | 多头% | 多空比 |
|:----:|:----:|::----:|:-----:|
| 早期(5/19-5/31) | 34% | 14% | 0.41 |
| 中期(6/1-6/13) | 29% | 20% | 0.69 |
| 近期(6/14-6/26) | 30% | 24% | **0.80** |

空头倾向在减弱 → 不是"为了唱空而唱空"而是随着市场数据调整。

**有数据源支撑：** 300条中29条(10%)引用了具体数据源(TrendForce、Tom's Hardware、投行报告)。AI泡沫论点有数据支撑而非纯情绪。

**致命缺陷（不纳入主力信源的理由）：**
- 0条长文（>300字）— 结论与80%的分区中篇一样，无深度分析
- 38天的历史大短无法验证预言准确率
- 内容大量重复（"泡沫"×23次，基本是同一论点的多种表述）

**推送角色：** 不单独采集，仅当唐史主任发出强烈买入信号时自动向Yahoo/Google验证他引用的数据（如"75个数据中心被叫停"是否仍成立）。权重15%。

**评估脚本：** `scripts/kol_deep_mofei.py`（300条）+ `scripts/kol_analyze_mofei.py`（100条快筛）

> ⚠️ **IT精英配比修正（2026-06-26数据验证）**：经80条/137天数据分析，他声称的"稳健60%/波动40%"是每周一固定复读的话术模板，并非实际交易记录。
> 实际"进攻组合"金额仅1,000-4,300元，总资产290万的0.15%而非声称的40%（116万）。137天内买入2次、卖出0次，未执行他本人科普的"股债动态再平衡"策略。
> **核定推送角色：仅保留"今天亏了X"作为情绪参考，不作为配比或定投节奏参考源。**

### 画像饱和确认流程

```python
# 4个饱和度指标（满足3个即饱和）
CRITERIA = {
    'sample_size': lambda n: n >= 80,
    'density_stable': lambda d: d < 0.15,  # 四分位密度差值<15%
    'signal_density': lambda d: d > 0.10 or '非信号类',
    'style_stable': True,  # 风格连续2次一致
}

# 渐进采集流程
Phase 0: 最近20条 - 初始画像草稿
Phase 1: 再30条(累计50) - 对比Phase 0一致性
Phase 2: 再30条(累计80) - 验证饱和
Validation: 对一个KOL拉到150+条 - 验证116条画像与150条一致
```

### 新赛道发现机制

扫描用户未持有的申万行业，看动量+博主话题+与已有持仓相关性。

**Done in this session (2026-06-26):**
Sector gap analysis comparing 唐史主任's 227 posts against user's 11-fund portfolio.

Result: User's tech coverage (科创50C+半导体C+沪港深科技C+ESG) already aligns with Tang's core industries. Three apparent gaps (消费/白酒, 金融/券商, 汽车) were disproven on close reading — Tang was analyzing, not recommending. Script: `scripts/kol_sector_gap.py`

**Methodology (data-driven, not inferred):**
1. Define your holding sectors from fund_tools.py FUND_CODES
2. Map each to the industry keywords the KOL uses (INDUSTRY_KW dict)
3. For each KOL industry topic, count mentions AND check if buy-signal words appear in the SAME post
4. If signal_pct > 30%, it's a candidate gap to investigate
5. CRITICAL: read the actual post text. A post containing both '买' and '白酒' is not automatically a buy recommendation — distinguish recommendation from analysis by reading the KOL's actual stance
6. Save gap analysis to /tmp/sector_gap.json for reference

## Chart / Infographic Strategy (Analyzed 2026-06-26)

### Two Different Kinds of "Charts"

| Type | Tool | Precision | Interactivity | Chinese Text | Best For |
|------|------|:---------:|:-------------:|:-----------:|----------|
| Data chart | matplotlib/plotly/echarts | ✅ Exact axes & values | ✅ Clickable/hoverable | ✅ Native | SPA dashboard, K-line, yield curves |
| Info-card | baoyu-infographic (FLUX AI) | ❌ No exact coordinate control | ❌ Static image | ❌ **Garbled** — FLUX cannot render CJK characters reliably | Weekend recap, comparison cards — **only if text is English or <10 Chinese chars** |

### When to Use Each

| Context | Text Push | Info-Card (baoyu) | Data Chart (SPA) |
|---------|:---------:|:-----------------:|:----------------:|
| Daily QQ push (this user uses QQ) | ✅ Primary — 30s read | ❌ Not embedded; images increase read time | ❌ N/A |
| Weekend recap card | — | ✅ bento-grid + corporate-memphis | — |
| Monthly review | Text | ✅ dashboard + corporate-memphis | — |
| SPA page (future) | — | — | ✅ echarts, interactivity |
| Blog post / content creation | — | ✅ | — |

### baoyu-infographic Layout Recommendations

| Scenario | Layout | Style | Rationale |
|----------|--------|-------|-----------|
| 周末回顾卡 | bento-grid | corporate-memphis | Multi-topic overview, clear sections |
| 信号时间线 | linear-progression | craft-handmade | Event-timeline structure |
| 持仓对比 | comparison-table | technical-schematic | Fund-to-fund comparison |
| 风险提示卡 | iceberg | aged-academia | Surface vs hidden risks |

**Key constraint for daily push:** The QQ platform delivers text natively. Adding images forces the user to tap to view → increases friction. Info-cards are for **non-urgent, reference-oriented** delivery (weekend, monthly), not for the 30-second decision window.

### User Formatting Preferences (captured 2026-06-26 from iterative corrections)

This user is specific about push format. Rules that MUST be followed:

1. **Tables for data, not prose.** 外盘、A股、持仓分组全部用 markdown 表格展示，禁用一个一个列数字写句子。
2. **No IT精英 section.** 他不在推送正文中出现，删除所有对他的引用。
3. **昨收A股标题必须标注具体日期.** Write `📊 昨收A股 · 6月25日(三)` not just `📊 昨收A股`.
4. **Emoji headers + clean hierarchy.** Use `━` separators, emoji-leading section headers, and clear visual structure.
5. **No Box labels.** Do not write "Box 1" / "发生了什么" / "影响评估" — the sections speak for themselves.
6. **No footer decorations.** No trailing `---` or `⚡ 自动生成 · 不构成投资建议 ⚡` at the bottom. End clean.
7. **博主信号用引用式.** For each KOL, quote their key post then summarize the signal. Not a bullet list of their life story.
8. **No excessive color.** Use 🔴🟢🟡 for direction, not for decoration.
9. **博主标注.** 唐史主任后标注 `[已验证6/6]`，其他博主不标注验证状态。

### 08:00 盘前简报模板

**Tue–Fri (normal) version:**
```
━━━ 今日参考 · M月D日(周X) ━━━

🌙 隔夜外盘
| 品种 | 收盘 | 涨跌 |
（表格展示道琼斯/标普/纳指/黄金/美元）

📊 昨收A股 · 月X日(周X)
| 指数 | 收盘 | 涨跌 |
（表格展示上证/科创/创业板等）

💰 持仓分组
| 分组 | 均涨跌 | 数量 | 状态 |

📰 博主信号

【唐史主任司马迁】[已验证6/6]
> 核心引用
→ 信号：方向+赛道

【小浣熊1230】
> 核心引用
→ 信号：风险/宏观判断

📌 今日关注
● 操作建议
● 新赛道关注（可选）
```

**Monday version (never say 隔夜):**
```
━━━ 今日参考 · M月D日(一) ━━━

🌙 上周五外盘关盘（周末无交易）
| 品种 | 收盘 | 涨跌 |
（表格展示道琼斯/标普/纳指/黄金/美元 — 标注为上周五数据）

📰 周末大事
● web_search 搜到的周末重大事件（政策/地缘/大宗）

📊 上周五A股收盘 · M月X日(周X)
| 指数 | 收盘 | 涨跌 |

💰 持仓分组
...

📰 博主信号（注意抓取周末新发的博文）

📌 今日关注
● 关注开盘后修复力度
● 操作建议
```

### 11:35 盘中速递

```
━━━ 盘中速递 · 11:35 ━━━

📊 上午走势
三大指数 + 分时特征 + 成交量

💰 持仓估算
分组盘中估算表格

📰 博主新信号（如有）
引用式展示

📌 下午关注
关键点位或操作建议
```

### 15:30 收盘复盘

**Tue–Thu (normal) version:**
```
━━━ 收盘复盘 · M月D日 ━━━

📊 收盘
| 指数 | 今开 | 收盘 | 涨跌 | 高低波幅 |
（表格展示三大指数+黄金ETF，包含开盘价）

📋 早盘判断验证
表格：判断项 | 结果 | 对错

💰 持仓收益
分组表现

📌 明日初判
```

**Friday version (add US market preview):**
```
━━━ 收盘复盘 · M月D日(五) ━━━

📊 收盘
...

📋 早盘判断验证
...

💰 持仓收益
...

🌙 今晚美股关注
● 21:30 美股开盘
● 关注科技股/黄金/美元走势
● 若有大幅波动，本周末将推送外盘速报

📌 下周初判
```
```

## Data Storage (JSONL + R2)

Store both raw input AND AI output for later analysis:

```
fund-system/
├── data/
│   ├── morning-briefs.jsonl    # raw + summary per day
│   ├── closing-reviews.jsonl   # predictions + actuals
│   └── accuracy.jsonl          # running accuracy stats
└── site/                       # SPA dashboard (future)
    ├── index.html
    └── ...
```

JSONL format (append-only, one JSON object per line):
```jsonl
{"_date":"2026-06-26","_stored_at":"...","type":"morning_brief",
 "raw_inputs":{"quotes":{...},"funds":{...},"kol_posts":{...}},
 "summary":{"market":"...","groups":{...},"kol_signals":[...]}}
```

## User Preferences (Data-Driven Mandate)

This user explicitly rejects inference-based claims about KOLs or strategies. Every assertion must be backed by quantitative evidence.

**Rules of engagement (from user's direct statements, captured 2026-06-26):**
1. "要以数据说话，不要以推断说话" — When evaluating a KOL, pull actual data and compute the metrics. Do not infer signal density from reputation or follower count.
2. "你决定有用没用，要有成熟方法论指导" — The agent decides data sufficiency using documented methodology (4-criteria saturation matrix), not arbitrary limits.
3. "你慢慢拉取扩大样本直到你觉得可用有用为止" — Data collection is iterative (Phase 0→1→2→validation), not a single fixed batch. Each phase re-evaluates whether to continue.
4. "要迭代以事实说话" — Strategy evolves based on actual observed data, not pre-conceived notions.
5. Strategy documents are versioned and uploaded to R2 — every iteration is recorded for traceability.
6. Reject any candidate KOL where the data shows <10% signal density or 0% long-form content — these are not viable signal sources regardless of reputation.
7. **Cross-verify all comment claims** — "评论里比如有人说挣了翻倍，也要以实际证据交叉验证，如果有人乱说呢。" Personal return reports in comments are unverifiable and must not be pushed as fact. Only KOL's own replies and sector names (cross-checked with market data) can be pushed. Aggregate sentiment direction is acceptable ("评论区情绪偏乐观") but never specific user claims.

## KOL Expansion: Following-List Analysis (Negative Finding)

2026-06-26: Analyzed 唐史主任司马迁's following list (98 of 181 followers) to find new signal sources.

**Result: No viable replacements or additions found.** Even well-known financial KOLs in his follow list have collapsed signal quality on Weibo:

| Famous KOL | Followers | Signal Density | Status |
|-----------|:---------:|:--------------:|:------:|
| 洪榕 (交易策略) | 357万 | 0% | Last post Jul 2025 |
| 侯宁 (空军司令) | 424万 | 0% | Only retweets since Nov 2025 |
| 扬韬 (职业投资者) | 138万 | 0% | Sporadic, no measurable signal |
| 狂龙十八段 (资金流派) | 123万 | 5% | Low density, short form |
| 陈果-投资策略 | 15万 | 10% | Avg 42 chars per post |
| 梦想家林奇 | 39万 | **30%** | Only promising one, but last post Oct 2025 |

**Methodology:** Pulled most recent 20 posts from 10 candidate KOLs via desktop API, calculated signal density (same SIGNAL_WORDS_MAP used for Tang), analyzed content depth (avg post length, deep post ratio), and checked posting recency.

**Takeaway:** High-follower-count financial KOLs on Weibo are generally not active signal sources. Don't assume popularity = signal value. 唐史主任司马迁 and 小浣熊1230 together already provide the best available signal coverage. Script: `/opt/data/scripts/kol_evaluate_candidates.py`

## Pitfalls

1. **Weibo CLI commands broken on headless servers** — `weibo weibos`, `weibo search`, `weibo profile` use mobile API (m.weibo.cn) which needs separate auth. Use desktop API directly (weibo.com/ajax/statuses/mymblog) with QR-login cookies.
2. **Fund API rate limiting** — 天天基金 API has per-IP limits. Space requests > 1s apart; use 10s timeout.
3. **Weibo credential expiry (~7 days)** — Plan for re-login. Monitor `weibo status` output.
4. **Cron 3-minute hard timeout** — Must use pre-script pattern for data collection. Agent-only phase should be fast (reading pre-parsed files + formatting).
5. **Model override silently not honored** — When pinning a model on the cron job, always include explicit `base_url` for custom providers. See cron-content-pipeline pitfalls.
6. **Market holidays — now handled via CHINESE_HOLIDAYS_2026 set + auto-scrape framework** — See `references/holiday-handling.md`. The SSE publishes next year's schedule in December. The pre-collection scripts write skip files (`_skip.txt`, `_noon_skip.txt`, `_closing_skip.txt`) on non-trading days, and all three cron prompts MUST check for these files in Step 1. For 2027+, rely on `_scrape_sse_holidays()` auto-scrape; if it fails, manually add a `CHINESE_HOLIDAYS_2027` set.
7. **Monday 08:00: never say "隔夜"** — US market last closed ~76h earlier (Sat 04:00 CST). Write "上周五外盘关盘" instead, and supplement with web_search for weekend events. See `references/timing-analysis.md`.
### Push images not archived — Images sent via MEDIA: protocol are ephemeral. Save R2 URL in the JSONL record for later retrieval.
1. **KOL comment analysis: triggered, not daily** — Weibo comments on signal posts can reveal sectors/positions the author intentionally omitted from the main post. E.g. 唐史主任's post "清杂毛接货" said nothing about sectors; comments revealed 锂电、面板/玻璃、配件龙头. But daily comment scraping is too noisy (539 comments/post, ~60% noise). Use only as triggered pattern: when KOL publishes a signal post (融资仓/加仓/右侧/触底), pull top 20-30 comments for supplementary analysis. Three-tier value extraction: (a) author's own replies (highest weight) → (b) high-liked sector-specific questions → (c) follower return reports as verification of direction. See `references/weibo-comment-analysis.md`.
1. **Weibo comment API: only `aj/v6/comment/big` works** — `weibo.com/ajax/statuses/buildComments` returns 参数错误. Use `weibo.com/aj/v6/comment/big?ajwvr=6&id={post_id}&from=singleWeiBo&page={n}` instead. Returns HTML — parse with regex for `node-type="root_comment"` blocks + `WB_text` for content.
1. **baoyu-infographic + Chinese text**
9. **Fund codes from screenshots are unreliable (~50% error rate)** — User-provided fund codes from screenshot OCR or manual transcription are frequently wrong. Always verify every fund code via the 天天基金 API before trusting it. Run verification script after any code update.
