# Cron Failure Triage

Common reasons cron jobs fail and how to diagnose/fix them.

## First Rule: Distinguish Code Failures from Delivery Failures

When a cron job shows `last_status: "error"`, the most common pitfall is **assuming the code failed** when actually the **content was generated correctly but delivery to the target platform(s) failed**.

**How to tell the difference:**

| Signal | Likely Code Error | Likely Delivery Error |
|--------|:-----------------:|:--------------------:|
| `last_status: "error"` | ✅ possible | ✅ possible |
| `last_delivery_error: "delivery error: ..."` | ❌ | ✅ **definitive** |
| `last_delivery_error: null` | ✅ likely | ❌ |
| Cron session shows partial/no output | ✅ likely | ❌ |
| Cron session shows full completed report | ❌ | ✅ likely |

**The diagnostic workflow — batch-run ALL failing jobs at once:**

When multiple cron jobs show errors, batch-run them all immediately:

```
cronjob(action="run", job_id="<job1_id>")
cronjob(action="run", job_id="<job2_id>")
cronjob(action="run", job_id="<job3_id>")
```

Then check their cron sessions after they complete and check gateway logs:

```bash
grep -i "delivery error\|delivered to\|delivery failed" /opt/data/logs/gateway.log | tail -20
```

**Interpreting the results:**

- **Code runs, delivery fails**: The cron session shows a complete agent response (report generated), but `last_delivery_error` has platform-specific errors. These are platform credential issues — fix by re-authenticating the platform. The cron job itself is fine.
- **Code fails**: The cron session has only the user message (no assistant response), or the assistant response is an error message. Check the model, skills, and prompt.

### Key Insight: Delivery Errors ≠ Code Errors

A cron job can:
- ✅ Generate content successfully
- ❌ Fail to deliver to one or more platforms
- ⚠️ Still show `last_status: "error"` system-wide

This is by design: `last_status` reflects whether delivery to ALL target platforms succeeded. If even one platform rejects the message, the whole job is marked `"error"`.

**Common delivery errors that look like code failures:**

```
delivery error: Weixin send failed: iLink sendmessage rate limited; cooldown active for 30.0s
  → WeChat rate limit. Re-trigger the cron run after 30s.

delivery error: QQBot: no access_token in response
  → QQ Bot credentials expired. Need new QQ_APP_ID / QQ_CLIENT_SECRET.

delivery error: Feishu send failed: obtain self tenant access token failed, code: 10014, msg: app secret invalid
  → Feishu app secret expired. Need new FEISHU_APP_SECRET.

delivery error: Telegram send failed: You must pass the token you received from https://t.me/Botfather!
  → Telegram bot token never configured. Need TELEGRAM_BOT_TOKEN.

delivery error: platform 'weixin' not configured/enabled
  → Weixin platform is NOT set up in gateway. Either configure it or remove from deliver field.

delivery error: cannot schedule new futures after interpreter shutdown
  → Gateway restart race. Re-trigger the cron run.
```

**Counter-intuitive scenario**: A delivery error on one platform cascades. If the deliver field lists 4 platforms and only 1 fails, the whole job shows `"error"` — but the other 3 platforms received the message. This makes TUI show `last_status: "error"` even when most deliveries succeeded.

## Skill Not Found

**Symptom:** `⚠️ Skill(s) not found and skipped: <name>` in cron session.

**Root cause:** The skill is installed in a non-standard path (e.g. `~/.agents/skills/`) and `skills.external_dirs` in config.yaml doesn't include it.

**Fix:**
1. Add the path to `config.yaml`: `skills.external_dirs: [~/.agents/skills]`
2. OR copy/symlink the skill to `~/.hermes/skills/<name>/`
3. Restart gateway so the new config is picked up by future cron sessions

## Model Override Not Honored (Silent Model Misrouting)

**Symptom:** `last_status: "error"`, `[Errno 32] Broken pipe` repeated across 3 retries. Job listing shows the expected model override, but API calls go to a different provider's base URL.

**Root cause:** The cron job's `model` override is stored in the database but NOT honored at runtime when:
- The main model provider was changed after the override was saved
- The override has `base_url: null` and the runtime cannot resolve the custom provider's base_url from config
- The runtime falls through to the current main provider instead

**Diagnosis — request dump files are the definitive tool:**

```bash
# Find request dumps for the failed cron run
ls /opt/data/sessions/request_dump_cron_<job_id>_*

# Check the ACTUAL API endpoint called (not what the job listing shows)
python3 -c "
import json, glob, os
dumps = sorted(glob.glob('/opt/data/sessions/request_dump_cron_<job_id>_*.json'),
               key=os.path.getmtime)
if dumps:
    d = json.load(open(dumps[-1]))
    r = d['request']
    print(f'Actual URL:    {r[\"url\"]}')
    print(f'Actual model:  {r[\"body\"][\"model\"]}')
else:
    print('No request dumps found — job may have succeeded or never started the LLM call')
"
```

Compare the Actual URL/Model against the cron job's stored override from `cronjob(action="list")`.

**Fix — update the job with explicit `base_url`:**

```python
cronjob(
    action="update",
    job_id="<job_id>",
    model={
        "provider": "custom:agnes",     # or your custom provider name
        "model": "agnes-2.0-flash",     # or your model name
        "base_url": "https://apihub.agnes-ai.com/v1"  # ← REQUIRED for custom providers
    }
)
```

**Key insight:** `cronjob(action="list")` shows what the override was **set to**, not what the runtime **actually used**. They can diverge silently. When a cron job starts failing after a main-model switch, always verify via request dumps.

## Systematic Diagnostic: Timeline of Model Changes

When a cron job works for days then suddenly fails:

```bash
# 1. Find all request dumps for this job
ls -lt /opt/data/sessions/request_dump_cron_<job_id>_*

# 2. Check which API was called at each point
for f in /opt/data/sessions/request_dump_cron_<job_id>_*; do
  python3 -c "
import json
d = json.load(open('$f'))
r = d['request']
from datetime import datetime
print(f'{datetime.fromisoformat(d[\"timestamp\"][:19])} → {r[\"url\"]} ({r[\"body\"][\"model\"]})')
"
done

# 3. The timestamp where the URL changes points to when the main model was switched
```

## Model Quota Exhaustion (429)

**Symptom:** Cron job `last_status: "error"`, or silently falls to paid model.

**Root cause:** The pinned model's free quota is exhausted (e.g. Gemini free tier: 1500 req/day, 30 req/min).

**Fix:**
1. Switch to a working model: `cronjob(action="update", job_id=..., model={"provider": "openrouter", "model": "deepseek/deepseek-v4-flash"})`
2. Test: `cronjob(action="run", job_id=...)`
3. Check result: `cronjob(action="list")` → verify `last_status: "ok"`

## Gateway Restart Race

**Symptom:** `delivery error: cannot schedule new futures after interpreter shutdown`

**Root cause:** Gateway was restarted while cron job was delivering its response.

**Fix:** Don't restart gateway within ~3 minutes of triggering a cron run. If it happens, just re-trigger the cron run.

## Cron Session Is Created But Never Produces Output

**Symptom:** `session_search()` shows a cron session with only the user message (the prompt), and no assistant response. `last_status: "error"` but `last_delivery_error: null`.

**Root cause:** The cron agent timed out or errored before producing any output. Common causes:
- **Model unavailable** — the pinned model returned HTTP error or timeout
- **Prompt too long** — very long prompts (especially with full skill content embedded, 5K+ tokens) overwhelm free-tier models
- **Agent stuck** — the agent loop hit max_turns or ran into a tool permission issue

**Diagnosis:**
```bash
# Check the session content — if only user message exists, the model never responded
session_search(session_id="cron_<job_id>_<timestamp>")

# Check model availability
hermes chat -q "hello" --provider <provider> --model <model> 2>&1 | head -5

# Check gateway logs for agent errors
grep "cron\|error\|timeout" /opt/data/.hermes/logs/agent.log | tail -10
```

**Fix:**
1. Verify the model works standalone (test with a simple query)
2. Shorten the cron prompt — remove verbose examples, keep only essential instructions
3. Switch to a more capable model for long prompts

## Systematic Batch Diagnosis (All-Jobs-at-Once Pattern)

When multiple cron jobs show errors, the most efficient approach:

```
1. cronjob(action="list")
2. cronjob(action="run") → for EVERY failing job (batch)
3. Wait for sessions to be created
4. session_search() → browse for new cron sessions
5. For each cron session, check if it produced output or only has user message
6. grep "delivery error" /opt/data/logs/gateway.log → check if deliveries failed
7. grep -i "error\|401\|token\|secret\|invalid" /opt/data/logs/gateway.log → platform-level errors
```

This pattern reveals:
- **Systemic issues** (all jobs failing the same way → model/skill/platform problem)
- **Code bugs** (single job failing differently from others)
- **Delivery problems** (jobs produce output but cannot deliver)

## Checklist for Diagnosing Any Cron Failure

```bash
# 1. Check cron job status — immediately reveals if it's a delivery error
cronjob(action="list")

# 2. Check the cron session for errors
session_search(query="cron_<job_id>", sort="newest")

# 3. Check gateway logs for delivery errors
grep -i "delivery error\|delivered to" /opt/data/logs/gateway.log | tail -10

# 4. Check platform authentication errors
grep -i "token\|secret\|invalid\|401" /opt/data/logs/gateway.log | tail -10

# 5. Check if the model works
hermes chat -q "hello" --provider <provider> --model <model> 2>&1 | head -5

# 6. Check skill availability
skill_view(name="<skill_name>")

# 7. Only after the above 6 checks fail to identify the issue — dig into code
```
