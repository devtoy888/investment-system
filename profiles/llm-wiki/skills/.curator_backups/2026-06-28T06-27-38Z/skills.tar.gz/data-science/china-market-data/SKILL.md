---
name: china-market-data
description: 中国A股/基金市场数据采集 — 腾讯行情(不封IP) + 天天基金净值 + mootdx(通达信TCP) + 东财(限流)数据接口，零API Key，pip安装即用。
origin: custom
---

# 中国金融市场数据采集

A股行情、基金净值、ETF、指数、资金流向等数据的一站式采集方案，全部免费、零API Key。

## 触发条件

- 用户需要拉取A股/基金/ETF/指数行情
- 用户需要基金净值或实时估值
- 用户需要北向资金、龙虎榜等市场信号
- 用户需要构建定时数据采集流水线

## 依赖安装

```bash
pip install mootdx requests pandas stockstats
```

## 数据源优先级

| 优先级 | 数据源 | 协议 | 封IP风险 | 用途 |
|-------|--------|------|---------|------|
| 1 | **腾讯财经** | HTTP | **不封** | 实时价/PE/PB/市值/指数/ETF - 首选 |
| 2 | **天天基金** | HTTP | 低 | 基金净值/实时估值 |
| 3 | **mootdx(通达信)** | TCP 7709 | **不封** | K线/五档/财务(海外IP可能超时) |
| 4 | 东财(限流) | HTTP | 有风控 | 龙虎榜/北向/资金流/研报(已内置限流) |
| 5 | 同花顺 | HTTP | 极低 | 热点题材/北向资金 |

> **核心原则：** 能用腾讯/天天就不用东财。腾讯接口实测不封IP。

## 关键API（已验证可用的）

### 1. 腾讯财经实时行情（不封IP）

```python
import requests

def get_tencent_quote(code):
    """获取个股/指数/ETF实时行情"""
    url = f"https://qt.gtimg.cn/q={code}"
    r = requests.get(url, timeout=5)
    line = r.text.strip().rstrip(';')
    if '="' in line:
        parts = line.split('="')[1].rstrip('"').split('~')
        return {
            'name': parts[1],
            'price': parts[3],
            'change_pct': parts[32],      # 涨跌幅%
            'change_amt': parts[31],       # 涨跌额
            'open': parts[5],
            'high': parts[33],
            'low': parts[34],
            'volume': parts[6],
            'turnover': parts[37],         # 换手率
            'pe': parts[39],               # 动态市盈率
            'pb': parts[46],               # 市净率
            'market_cap': parts[45],       # 总市值
            'float_cap': parts[44],        # 流通市值
        }
    return None
```

**代码前缀规则：** 6/9开头 → `sh`, 8开头 → `bj`, 其他 → `sz`

**常用代码：**
- 上证指数: `sh000001`
- 创业板指: `sz399006`
- 科创50: `sh000688`
- 沪深300: `sh000300`
- 上证50: `sh000016`
- 黄金ETF: `sz159934`
- 黄金ETF(沪): `sh518880`

### 2. 天天基金净值/实时估值（免费）

```python
import requests, json

def get_fund_value(fund_code):
    """获取基金当日净值+实时估算"""
    url = f"https://fundgz.1234567.com.cn/js/{fund_code}.js"
    r = requests.get(url, timeout=5,
        headers={'Referer': 'https://fund.eastmoney.com/'})
    txt = r.text.strip()
    if 'jsonpgz(' in txt:
        data = json.loads(txt[txt.index('(')+1:txt.rindex(')')])
        return {
            'name': data.get('name'),
            'nav': data.get('dwjz'),           # 昨日净值
            'estimated_nav': data.get('gsz'),   # 实时估算净值
            'estimated_change': data.get('gszzl'),  # 估算涨幅%
            'nav_date': data.get('jzrq'),       # 净值日期
        }
    return None
```

### 3. mootdx 通达信TCP（含BESTIP修复）

> **已知Bug (mootdx 0.11.x):** 全新安装后`Quotes.factory()`可能抛`ValueError`。用下面helper规避。

```python
import socket
from mootdx.quotes import Quotes

_TDX_SERVERS = [
    ('119.97.185.59', 7709), ('124.70.133.119', 7709), ('116.205.183.150', 7709),
    ('123.60.73.44', 7709),  ('116.205.163.254', 7709), ('121.36.225.169', 7709),
    ('123.60.70.228', 7709), ('124.71.9.153', 7709),    ('110.41.147.114', 7709),
    ('124.71.187.122', 7709),
]

def tdx_client(market='std'):
    for ip, port in _TDX_SERVERS:
        try:
            with socket.create_connection((ip, port), timeout=2):
                return Quotes.factory(market=market, server=(ip, port))
        except Exception:
            continue
    # fallback
    try: return Quotes.factory(market=market, bestip=True)
    except Exception: pass
    raise RuntimeError("所有mootdx服务器不可达，海外网络通常全部超时")
```

### 4. 东财统一限流入口

```python
import time, random
import requests

EM_SESSION = requests.Session()
EM_SESSION.headers.update({"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"})
EM_MIN_INTERVAL = 1.0
_em_last_call = [0.0]

def em_get(url, params=None, headers=None, timeout=15):
    """东财统一请求入口：自动节流+复用session"""
    wait = EM_MIN_INTERVAL - (time.time() - _em_last_call[0])
    if wait > 0:
        time.sleep(wait + random.uniform(0.1, 0.5))
    try:
        return EM_SESSION.get(url, params=params, headers=headers, timeout=timeout)
    finally:
        _em_last_call[0] = time.time()
```

## 完整示例

```python
from china_market_data import get_tencent_quote, get_fund_value

# 大盘行情
sh = get_tencent_quote('sh000001')
print(f"上证指数: {sh['price']} ({sh['change_pct']}%)")

# 基金净值
fund = get_fund_value('002963')
print(f"易方达黄金ETF联接C: 净值={fund['nav']} 估算={fund['estimated_change']}%")
```

## Weibo KOL 信号采集

监控关注的财经大V（唐史主任司马迁、it精英带你养基、小浣熊1230等）的最新微博，用于信号判断和今日参考。

### 安装 weibo-cli

```bash
uv tool install kabi-weibo-cli
export PATH="$HOME/.local/bin:$PATH"
```

### 二维码登录（服务器无浏览器环境）

weibo-cli 支持 `weibo login --qrcode`，但在无头/远程服务器上无法扫描终端ASCII二维码。

**正确做法：** 用 Python 调用 passport.weibo.com API 获取二维码内容的 URL，用 `qrcode+PIL` 生成 PNG 图片，发给用户扫码。见 `references/weibo-qr-login.md`。

用户扫码登录后，凭据自动保存到 `~/.config/weibo-cli/credential.json`（7天有效，到期自动过期需重新登录）。

### 常用命令

```bash
# 获取用户最新微博
weibo weibos <UID> --count 5 --json

# 搜索微博
weibo search "keyword" --json

# 检查登录状态
weibo status

# 查看热榜
weibo hot --count 10
```

### KOL 采集流程（推荐：桌面API + 预采集脚本）

weibo weibos 和 weibo search CLI 命令使用 mobile API（m.weibo.cn），需要与桌面端不同的 cookie，在无头服务器上通常返回 ok=-100 会话过期错误。

解决方案：使用桌面 API（weibo.com）直接调用：

```python
import httpx, json
from pathlib import Path

CREDENTIAL_FILE = Path.home() / '.config' / 'weibo-cli' / 'credential.json'

def get_user_weibos(uid, count=5):
    if not CREDENTIAL_FILE.exists():
        return []
    cred = json.loads(CREDENTIAL_FILE.read_text())
    r = httpx.get('https://weibo.com/ajax/statuses/mymblog',
        params={'uid': uid, 'page': '1', 'feature': '0'},
        cookies=cred['cookies'],
        headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Referer': 'https://weibo.com/',
            'X-Requested-With': 'XMLHttpRequest',
        }, timeout=15)
    data = r.json()
    if data.get('ok') == 1:
        return data['data']['list'][:count]
    return []
```

提取字段：post['text_raw']（纯文本）, post['created_at'], post['reposts_count'] 等。

每采集一个用户间隔 >= 2 秒，避免频率限制。桌面API使用QR登录cookie（~/.config/weibo-cli/credential.json），有效期约7天。

### 基金持仓分组模式

当用户持有 ETF 联接+主动基金组合时，建议按主题分组分析而非逐支分析：

```python
FUND_GROUPS = {
    '科技': ['011613', '012552', '016803', '012045'],
    '黄金': ['002963', '009477'],
    '其他': ['013209', '012879', '014280', '013403', '016298'],
}

def group_funds(fund_data):
    for group_name, codes in FUND_GROUPS.items():
        changes = []
        for code in codes:
            v = fund_data.get(code)
            if v and v.get('estimated_change'):
                changes.append(float(v['estimated_change']))
        avg = round(sum(changes) / len(changes), 2) if changes else 0
        yield (group_name, avg, len(changes))
```

同主题基金联动性强，操作上一起考虑。

## 关于 a-stock-data

GitHub: `simonlin1212/a-stock-data` — 这是一个 **28 端点 SKILL.md 文件**，不是 pip 安装包。它封装了 mootdx+腾讯+东财+同花顺+新浪+百度共 13 个数据源的代码块。

```bash
# 只需装依赖，SKILL.md 作为参考查阅
pip install mootdx requests pandas stockstats
```

28 个端点覆盖：行情层、研报层、信号层、资金面、新闻、基础数据、公告。东财接口已内置 `em_get()` 限流防封。

## 常见陷阱

1. **海外网络 → mootdx不可达**：通达信TCP 7709在海外基本全超时，回退到腾讯财经API
2. **东财封IP**：每秒超5次或1分钟超200次会临时封禁，必须用`em_get()`限流
3. **基金代码C类/A类**：C类免申购费适合短期持有，A类收申购费适合长期持有
4. **腾讯返回列表索引超出**：腾讯API返回时field数量有细微差异，`split('~')`后检查长度再取值

## 参考文件

- `references/api-endpoints.md` — 已验证的API端点汇总
- `references/weibo-qr-login.md` — 无头服务器微博二维码登录方案
- `scripts/weibo_qr_login.py` — 可复用的微博QR登录脚本（monkey-patch方式）
