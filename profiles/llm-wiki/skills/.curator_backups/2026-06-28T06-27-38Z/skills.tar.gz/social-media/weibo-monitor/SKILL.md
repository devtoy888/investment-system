---
name: weibo-monitor
description: Monitor Weibo (微博) users for posts and signals — install, authenticate, collect posts from followed bloggers via CLI. Integrates with cron-content-pipeline for automated signal detection.
category: social-media
---

# Weibo Monitor

Monitor specific Weibo users' posts for investment signals, market commentary, or content curation. Uses [weibo-cli](https://github.com/jackwener/weibo-cli) (`kabi-weibo-cli` on PyPI) as the backend.

## When to Activate

- User wants to collect posts from specific Weibo bloggers
- User needs to monitor Weibo for signals (investment tips, market views)
- User wants to integrate Weibo data into a daily briefing or cron pipeline
- Keywords: 微博, weibo, 博主, signal, monitoring, 唐史主任司马迁

## Prerequisites

```bash
uv tool install kabi-weibo-cli
```

## Authentication (Headless Server)

Weibo requires login. On a headless server (no browser), use QR code login:

```bash
weibo login --qrcode
```

**Problem:** The QR code renders as ASCII art in the terminal. On platforms like QQ/WeChat, ASCII QR codes are not scannable.

**Fix:** Use this Python monkey-patch to also save the QR as a PNG image, then send via `MEDIA:` protocol:

```python
import sys, httpx, qrcode
from urllib.parse import parse_qs, urlparse
from pathlib import Path

PASSPORT_URL = "https://passport.weibo.com"
QR_IMAGE_URL = "/sso/v2/qrcode/image"
QR_CHECK_URL = "/sso/v2/qrcode/check"
SSO_SIGNIN_URL = "/sso/signin"
QR_ENTRY = "miniblog"
QR_SOURCE = "miniblog"
QR_REDIRECT_URL = "https://weibo.com/"
QR_VERSION = "20250520"
RETCODE_SUCCESS = 20000000

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/145.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "x-requested-with": "XMLHttpRequest",
}

CONFIG_DIR = Path.home() / ".config" / "weibo-cli"
CREDENTIAL_FILE = CONFIG_DIR / "credential.json"

with httpx.Client(base_url=PASSPORT_URL, headers=dict(HEADERS), follow_redirects=True, timeout=30) as client:
    # Step 1: CSRF token
    client.get(SSO_SIGNIN_URL, params={"entry": QR_ENTRY, "source": QR_SOURCE, "url": QR_REDIRECT_URL})
    csrf = client.cookies.get("X-CSRF-TOKEN")
    client.headers["x-csrf-token"] = csrf

    # Step 2: Request QR code
    resp = client.get(QR_IMAGE_URL, params={"entry": QR_ENTRY, "size": "180"})
    data = resp.json()
    qrid = data["data"]["qrid"]
    parsed = urlparse(data["data"]["image"])
    scan_url = parse_qs(parsed.query)["data"][0]

    # Step 3: Save as image
    qrcode.make(scan_url).save("/tmp/weibo_qr.png")
    print(f"QR_IMAGE_PATH:/tmp/weibo_qr.png")

    # Step 4: Poll for scan (4 min timeout)
    for _ in range(120):
        time.sleep(2)
        r = client.get(QR_CHECK_URL, params={"entry": QR_ENTRY, "qrid": qrid, "rid": "", "ver": QR_VERSION})
        rc = r.json().get("retcode")
        if rc == 50114002: print("已扫码,等待确认...")
        elif rc == RETCODE_SUCCESS:
            # Follow crossdomain & save credential
            for url in (r.json().get("data",{}).get("crossdomain_url","") or "").split(","):
                if url.strip(): httpx.get(url.strip(), follow_redirects=True, timeout=10)
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            CREDENTIAL_FILE.write_text(__import__("json").dumps({"cookies": dict(client.cookies)}))
            print("✅ 登录成功")
            break

# Alternative: use the built-in command (simpler but no image file)
# weibo login --qrcode   # shows ASCII QR only
```

### Verify Authentication

```bash
weibo status
# Expected: authenticated: true, cookie_count: 6+

# Test: fetch hot search (desktop API, no auth needed)
weibo hot --count 3
```

## Finding User IDs

Weibo uses numeric user IDs (UIDs). The `weibo search` command uses the mobile API which requires separate authentication — it often fails on headless servers.

**Best approach:** Ask the user for the UIDs directly. They can find them from the Weibo app: open the blogger's profile → tap "..." → copy link → the `/u/` number is the UID.

**Alternative (requires desktop auth):** Use the confirmed desktop API directly:

```python
import httpx, json
cred = json.loads(open(CREDENTIAL_FILE).read())
headers = {"User-Agent": "Mozilla/5.0 ...", "X-Requested-With": "XMLHttpRequest"}
r = httpx.get("https://weibo.com/ajax/statuses/mymblog",
    params={"uid": "2014433131", "page": "1", "feature": "0"},
    cookies=cred["cookies"], headers=headers)
# r.json()["data"]["list"] → posts
```

## Collecting User Posts (Desktop API)

The desktop API (`weibo.com/ajax/statuses/mymblog`) works reliably with the QR-login credentials. Use direct Python calls rather than the CLI for automated scripts:

```python
def get_user_weibos(uid, page=1):
    cred = json.loads(open(CREDENTIAL_FILE).read())
    r = httpx.get("https://weibo.com/ajax/statuses/mymblog",
        params={"uid": uid, "page": str(page), "feature": "0"},
        cookies=cred["cookies"],
        headers={"User-Agent": "Mozilla/5.0 ...", "X-Requested-With": "XMLHttpRequest"})
    return r.json()["data"]["list"]

# Extract key info from each weibo:
# post["id"], post["text"] (HTML content), post["created_at"], post["user"]["screen_name"]
```

## Known Users (UIDs)

| 昵称 | UID | 粉丝 | 认证 |
|------|-----|------|------|
| 唐史主任司马迁 | 2014433131 | 4900万+ | 财经博主 |
| IT精英带你养基 | 5044466342 | 160万 | 财经博主,微博原创视频博主 |
| 小浣熊1230 | 6114912545 | 4.5万 | 投资内容创作者,财经观察官 |

## Expanded Black Talk Dictionary (唐史主任司马迁-Specific)

Analysis of 227 posts (2024-05 to 2026-06) revealed unique industry-specific vocabulary:

| Term | Meaning | Context |
|------|---------|---------|
| **玻璃基** | Corning GlassBridge, AI数据中心光学互连技术 | 光通信/AI集群互连 |
| **长鑫** | 长鑫存储（CXMT）, 国产DRAM龙头 | 国产替代核心 |
| **伴娘** | 供应链配套厂商 | "长鑫伴娘"=长鑫的供应商 |
| **大fab / 小fab** | 大型/小型晶圆代工厂 | 产业链细分 |
| **硅基通胀** | AI算力推高芯片全链条价格 | 整体涨价逻辑 |
| **存** | 存储芯片（DRAM/HBM） | 出现16次，核心赛道 |
| **实调** | 实地调研、产业调研 | 信息来源标记 |
| **拥挤度** | 板块交易集中度高 | 回调预警信号 |
| **场外资金** | 增量机构资金入场 | 做多信号 |
| **宽基** | 宽基ETF（沪深300/中证500等） | 资金流向指标 |
| **季末漂移** | 基金季末调仓导致的板块异动 | 短期噪音 |
| **低位ETF** | 低位ETF品种，机构抄底 | 做多信号 |
| **功率** | 功率半导体（IGBT/SiC） | 科技细分赛道 |

Full black talk analysis: `kol_blacktalk_analysis.json` on R2 at `fund-system/data/`.

## Getting Following List

To analyze who a user follows:

```python
# Desktop API endpoint
url = "https://weibo.com/ajax/friendships/friends"
params = {"uid": TARGET_UID, "page": "1"}

# Returns per page (~20 users), paginate with &page=N
# Fields: screen_name, followers_count, friends_count, statuses_count, 
#         verified, description, verified_reason
# Endpoint maxes out at ~25 pages (~500 users) before returning empty
```

Scripts used: `/opt/data/scripts/kol_tang_following.py`, `/opt/data/scripts/kol_classify_following.py`, `/opt/data/scripts/kol_evaluate_candidates.py`

财经博主（尤其是唐史主任司马迁）常用暗语/黑话代指市场术语。采集帖子后做 AI 解读能大幅提升信号价值。

### 内置关键词规则（轻量版，适合预采集脚本）

```python
SIGNAL_MAP = {
    '村里': '政策层面/监管层',
    '上面': '高层/监管机构',
    '大家伙': '大资金/机构/国家队',
    '聪明钱': '北向资金/外资',
    '老乡': '散户投资者',
    '掌柜': '基金经理/操盘手',
    '开会': '政策会议/重要消息即将发布',
    '风向': '政策导向/市场趋势',
    '地板': '股价处于底部区域',
    '天花板': '股价到达顶部区域',
    '半山腰': '股价处于中间位置，可上可下',
    '吃肉': '有盈利空间/行情启动',
    '抬轿': '追高买入/给别人抬价格',
    '砸盘': '大资金卖出打压股价',
    '护盘': '资金托市/维稳',
    '出货': '主力卖出离场',
    '建仓': '主力开始买入',
    '洗盘': '主力震荡清洗散户筹码',
    '右侧': '趋势确认后的上涨阶段',
    '左侧': '趋势尚未确认的底部阶段',
    '确定性': '有明确逻辑支撑的投资机会',
    '弹性': '涨跌幅大的品种/高风险高收益',
    '高低切': '资金从高位板块流向低位板块',
    '高低切换': '板块轮动/风格转换',
}
```

### AI 深度解读（完整版，适合 cron agent）

在 cron agent prompt 中要求模型对微博原文做解读，效果比关键词规则好。完整词典见 `references/weibo-black-talk.md`。

```
对唐史主任司马迁的最新微博做解读：
- 他用了什么暗语/黑话？实际含义是什么？
- 他整体传递了什么市场观点？
- 这个观点对你的持仓有什么影响？
```

## Known credential location

```bash
# Credential file auto-saved at:
~/.config/weibo-cli/credential.json

# Verify:
weibo status  # → authenticated: true, cookie_count: 6+

# On credential expiry (~7 days), re-run QR login:
weibo login --qrcode  # generates ASCII QR in terminal
# OR use the Python monkey-patch script above to save PNG
```

## Pitfalls

1. **Mobile API needs separate auth** — `weibo search`, `weibo weibos`, `weibo profile` commands use `m.weibo.cn` which needs its own cookie. On headless servers, these commands often fail with `ok: -100`. **Fix:** Use desktop API endpoints directly (`weibo.com/ajax/statuses/mymblog`).
2. **Cookie expiration** — Credentials last ~7 days. Re-run QR login when `weibo status` shows `authenticated: false`.
3. **ASCII QR in terminal** — Never assume the user can scan ASCII QR codes from chat platforms. Always save a PNG image.
4. **Overseas network** — `passport.weibo.com` and `weibo.cn` may be slow or timeout from overseas servers. Desktop API (`weibo.com`) is more reliable.
6. **Famous ≠ valuable — follower count does not predict signal quality.** 
   Tested this hypothesis (2026-06): pulled 20 recent posts from 10 well-known financial KOLs (356K-640K followers) that 唐史主任 follows. 
   **Result:** Signal density ranged 0-10% for 9/10. Most have stopped posting substantive content or only share personal life. 
   **Meaning:** Do not assume popular KOLs produce actionable signals. Always measure: pull 20 posts, compute actual signal density, check posting recency. 
   The one exception (梦想家林奇, 30% density) had also stopped posting since Oct 2025. 
   **Conclusion:** 唐史主任 + 小浣熊 already provide the best available signal coverage on Weibo. Adding more from the following list yields diminishing returns.
7. **Following list API** — `weibo.com/ajax/friendships/friends?uid={UID}&page={N}` returns up to ~500 users (25 pages × 20). Works with QR-login cookies.
